# 嘉立创EDA Codex Bridge

这个本地 Codex 插件把 Codex 接入嘉立创EDA专业版 V3。它包含：

- 一个 Codex MCP 服务，提供状态、启动、窗口选择、精简上下文、设计审计、API 检索和受保护代码执行工具；
- 嘉立创官方 `easyeda-api-skill` 的 API/格式资料；
- 与本机安装匹配的扩展 API `0.2.53` 类型快照；
- 已构建的官方 `run-api-gateway_v1.0.5.eext`。

## 安装到 Codex

在 PowerShell 中执行：

```powershell
codex plugin marketplace add "D:\Installation\jlceda\_plugin"
codex plugin add jlceda-codex-bridge@jlceda-local
```

也可以运行根目录的 `install-codex-plugin.ps1`。安装完成后新建一个 Codex 任务，使技能与 MCP 工具被重新加载。

## 安装嘉立创EDA扩展

1. 启动 `D:\Installation\lceda-pro\lceda-pro.exe`。
2. 打开 **高级 → 扩展管理器 → 导入**。
3. 选择 `plugins\jlceda-codex-bridge\assets\run-api-gateway_v1.0.5.eext`。
4. 如果扩展管理器要求“外部交互”权限，请启用。
5. 重启嘉立创EDA。

## 使用

可以在新任务里直接说：

- “检查当前嘉立创EDA工程和活动文档。”
- “用精简模式审计当前原理图的网络端口、重复标记和 ERC。”
- “读取当前 PCB 的选中图元，不要修改。”
- “先查 API，再把选中走线宽度改为 10 mil。”
- “运行一次 DRC 并解释结果。”

MCP 服务启动时会自动发现或创建本机桥接服务。嘉立创扩展会扫描 `127.0.0.1:49620-49629` 并连接。多个 EDA 窗口同时打开时，可以先列出窗口再选择目标。

## 精度与 Token 优化

- `get_context` 默认只返回工程、板、原理图页、PCB 和活动文档的必要字段，不再回传整份标题栏数据。
- `inspect_design` 内置原理图网络端口/重复坐标/ERC 与 PCB 图元/DRC 摘要，减少重复编写长 JavaScript 扫描脚本。
- `search_api` 使用缓存索引和相关度排序，支持部分词覆盖、作用域与路径过滤；默认最多返回 8 段短上下文。
- `execute` 支持工程/文档 UUID 与文档类型守卫，避免在错误标签页执行；支持 5–120 秒超时和结构化输出预算。
- 所有 MCP JSON 默认使用紧凑编码；大数组、长字符串和深层对象会按预算摘要，可按需显式请求 `outputMode: "full"`。
- 超时会返回 `requestId` 和“结果未知”提示；本进程拥有桥接服务时可用 `request_status` 查询迟到结果，否则必须先回读设计状态再重试。

## 安全说明

- 桥接服务只监听 `127.0.0.1`，不会监听局域网地址。
- `execute` 可以修改当前设计，在 Codex 中被配置为每次调用前请求确认。
- `inspect_design` 和 `request_status` 是只读工具，不新增对外 HTTP 数据查询端点。
- `launch` 和窗口切换同样需要确认。
- HTTP 执行端点用于同一台电脑上的多个 Codex 任务复用官方桥接协议，因此本机其他进程理论上也能调用它。不要在不可信的共享 Windows 会话中启用此插件。
- 修改前请保存工程；项目切换可能丢弃未保存内容。

## 本机兼容性

- 嘉立创EDA程序：`D:\Installation\lceda-pro\lceda-pro.exe`
- 检测到的应用版本：`3.2.149.88089769`
- 检测到的扩展 API：`0.2.53`
- 网关扩展：`1.0.5`，要求 EDA `~3.2.0`
- Node.js：18 或更高版本

## 源码与重建

MCP 源码位于 `src/mcp-server.mjs`，运行 `npm ci` 后执行 `npm run build` 可重新生成 `server/server.mjs`。嘉立创扩展来自官方 `easyeda/eext-run-api-gateway` 项目；API 文档来自官方 `easyeda/easyeda-api-skill` 项目。
