import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { StdioClientTransport } from '@modelcontextprotocol/sdk/client/stdio.js';

const pluginRoot = dirname(dirname(fileURLToPath(import.meta.url)));
const transport = new StdioClientTransport({
  command: process.execPath,
  args: [join(pluginRoot, 'server', 'server.mjs')],
  cwd: pluginRoot,
  stderr: 'pipe',
});
const client = new Client({ name: 'jlceda-bridge-live-smoke', version: '1.0.0' });

try {
  await client.connect(transport);
  const status = await client.callTool({ name: 'status', arguments: {} });
  const statusPayload = JSON.parse(status.content[0].text);
  if (!statusPayload.edaConnected) {
    process.stdout.write(JSON.stringify({ skipped: true, reason: 'No 嘉立创EDA window is connected.' }) + '\n');
    process.exitCode = 0;
  }
  else {
    const context = await client.callTool({
      name: 'get_context',
      arguments: { detail: 'summary', maxOutputChars: 8_000 },
    });
    const contextPayload = JSON.parse(context.content[0].text);
    if (!contextPayload.success || !contextPayload.result?.document) {
      throw new Error('Compact context did not return an active document.');
    }

    const inspection = await client.callTool({
      name: 'inspect_design',
      arguments: { includeDrc: false, sampleLimit: 2, maxOutputChars: 8_000, timeoutMs: 60_000 },
    });
    const inspectionPayload = JSON.parse(inspection.content[0].text);
    if (!inspectionPayload.success || !inspectionPayload.result?.kind) {
      throw new Error('Design inspection did not return a supported result.');
    }

    process.stdout.write(JSON.stringify({
      connectedWindows: statusPayload.edaWindowCount,
      contextChars: context.content[0].text.length,
      inspectionChars: inspection.content[0].text.length,
      project: contextPayload.result.project?.friendlyName || contextPayload.result.project?.name,
      documentType: contextPayload.result.document.documentType,
      inspectionKind: inspectionPayload.result.kind,
      counts: inspectionPayload.result.counts,
    }) + '\n');
  }
}
finally {
  await client.close();
}
