---
name: easyeda-api
description: Connect Codex to 嘉立创EDA专业版 (EasyEDA Pro) for PCB, schematic, footprint, symbol, library, project, DRC, and extension-API work. Use whenever the user asks to inspect or operate 嘉立创EDA, EasyEDA Pro, PCB design, schematics, footprints, or the current EDA project through the local bridge.
license: Apache-2.0
metadata:
  author: Local integration based on official EasyEDA API resources
  version: "0.1.0"
---

# 嘉立创EDA Codex Bridge

Use the `jlceda` MCP tools to inspect and operate 嘉立创EDA专业版. The local MCP server also hosts the WebSocket endpoint expected by the official Run API Gateway extension.

## Connect

1. Call `status`. This starts or discovers the local bridge and reports whether the executable and packaged `.eext` asset exist.
2. If no EDA window is connected, tell the user to import `assets/run-api-gateway_v1.0.5.eext` in 嘉立创EDA V3 via **高级 → 扩展管理器 → 导入**, enable external interaction permission when requested, and restart 嘉立创EDA. Use `launch` only with the user's approval.
3. Call `list_windows`. If one window is connected it is selected automatically. If several are connected, show the IDs and use `select_window` after the user identifies the intended window.
4. Call `get_context` with its default `detail: "summary"` before the first design operation and after a disconnected-window error. Use `detail: "full"` only when raw project metadata or title-block fields are necessary.

## Precision and token efficiency

- Prefer `inspect_design` over a long one-off `execute` program for component/wire counts, marker mismatches, duplicate markers, net summaries, and ERC/DRC.
- Keep `sampleLimit` at 10 or lower until a count shows that more examples are needed.
- Search exact symbols first, for example `SCH_PrimitiveComponent.createNetPort`, with `scope: "api"`. Add `pathPrefix` only when the class, enum, or interface family is known.
- `search_api` ranks partial coverage, but one class or operation per query is usually the smallest and most precise request.
- Keep compact output by default. Request `outputMode: "full"` only for a narrowly filtered query and set `maxOutputChars` deliberately.
- In custom `execute` code, return counts, IDs, distributions, and bounded samples instead of raw primitive objects or complete project trees.
- Do not repeat `status`, `list_windows`, or full context reads while the selected window and target remain unchanged.

## Look up APIs before execution

Never guess an API name, signature, enum, coordinate unit, or return type.

- Start with `search_api` or read `references/_index.md` and `references/_quick-reference.md`.
- Read the relevant class document under `references/classes/`.
- Read enum and interface documents when parameters use those types.
- The installed application exposes extension API `0.2.53`; prefer `references/local/api-types-0.2.53.d.ts` when generated documentation and the local installation differ.
- Use `format/` only when the task is specifically about project, schematic, or PCB source-file structure.

## Execute safely

The `execute` tool runs its `code` value as the body of `async function(eda) { ... }` inside 嘉立创EDA.

- Always use `await` for Promise-returning API methods.
- Always include `return` with a JSON-serializable value; console output is not returned.
- Use documented enum members instead of guessed raw numbers.
- Verify the active project and document type before calling PCB or schematic APIs.
- After `get_context`, pass `guard.projectUuid`, `guard.documentUuid`, and `guard.documentType` to every mutating `execute` call. The bridge checks them before user code runs, replacing repetitive in-code target checks.
- Prefer a read-only query first. Before a mutating call, state the intended design change and its scope.
- Do not open or switch projects when unsaved changes might be discarded unless the user explicitly approves.
- Do not use Node.js APIs, DOM access, `window`, or `localStorage` in the extension main runtime. Use documented `eda.sys_*` APIs.
- After a mutation, read back the affected object or run the relevant check so the result is verifiable.
- Do not call an undocumented method. If the reference does not establish a valid method and signature, stop and explain the limitation.
- Batch repetitive beta-API mutations conservatively (normally 20 items per call). Set `timeoutMs` high enough for the planned batch instead of immediately retrying a timed-out mutation.
- If a timed-out call returns a `requestId`, call `request_status` when available. If the MCP process uses a shared proxy bridge, inspect design state before any retry because the first call may have completed late.

## Units and state

- PCB coordinates: `1 unit = 1 mil = 0.0254 mm`.
- Schematic coordinates: `1 unit = 0.01 inch = 10 mil = 0.254 mm`.
- PCB operations require an active PCB document; schematic operations require an active schematic page.
- Primitive edits commonly require `toAsync()`, setters, and `done()`; confirm the exact class documentation first.

## Useful read-only patterns

Current project:

```javascript
return await eda.dmt_Project.getCurrentProjectInfo();
```

Current document:

```javascript
return await eda.dmt_SelectControl.getCurrentDocumentInfo();
```

All boards:

```javascript
return await eda.dmt_Board.getAllBoardsInfo();
```

Selected PCB primitive IDs:

```javascript
return eda.pcb_SelectControl.getAllSelectedPrimitives_PrimitiveId();
```

DRC:

```javascript
return await eda.pcb_Drc.check(true, true, false);
```

Compact guarded mutation arguments:

```json
{
  "guard": {
    "projectUuid": "<from get_context>",
    "documentUuid": "<from get_context>",
    "documentType": 3
  },
  "timeoutMs": 60000,
  "outputMode": "compact",
  "maxOutputChars": 12000
}
```

## Troubleshooting

- Bridge running but zero EDA windows: import/enable the `.eext`, allow external interaction, restart EDA, then call `status` again.
- Several windows: call `list_windows`, select explicitly, then retry.
- Timeout: use the returned `requestId` when locally available; otherwise inspect project/document state before retrying. Then reduce the batch size or raise `timeoutMs` within the tool limit.
- Permission error or repeated `null`: verify the call against the exact local type snapshot; the current license, project, or document state may restrict the API.
- API mismatch: report the installed app version and API version; do not silently substitute an undocumented call.
