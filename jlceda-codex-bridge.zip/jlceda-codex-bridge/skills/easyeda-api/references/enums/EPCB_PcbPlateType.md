# EPCB\_PcbPlateType enum

PCB plate type

## Signature

```typescript
enum EPCB_PcbPlateType
```

## Enumeration Members

<table><thead><tr><th>

Member

</th><th>

Value

</th><th>

Description

</th></tr></thead>
<tbody><tr><td>

FPC

</td><td>

`2`

</td><td>

</td></tr>
<tr><td>

NORMAL

</td><td>

`1`

</td><td>

</td></tr>
</tbody></table>