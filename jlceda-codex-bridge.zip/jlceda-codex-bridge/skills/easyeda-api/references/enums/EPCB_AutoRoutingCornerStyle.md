# EPCB\_AutoRoutingCornerStyle enum

Auto routing corner style

## Signature

```typescript
enum EPCB_AutoRoutingCornerStyle
```

## Enumeration Members

<table><thead><tr><th>

Member

</th><th>

Value

</th><th>

Description

</th></tr></thead>
<tbody><tr><td>

DEGREE\_45

</td><td>

`0`

</td><td>

</td></tr>
<tr><td>

DEGREE\_90

</td><td>

`1`

</td><td>

</td></tr>
</tbody></table>