# ESCH\_PrimitiveFillStyle enum

Fill style

## Signature

```typescript
enum ESCH_PrimitiveFillStyle
```

## Enumeration Members

<table><thead><tr><th>

Member

</th><th>

Value

</th><th>

Description

</th></tr></thead>
<tbody><tr><td>

GRID

</td><td>

`'Grid'`

</td><td>

</td></tr>
<tr><td>

HORIZONTAL\_LINE

</td><td>

`'Horizontal Line'`

</td><td>

</td></tr>
<tr><td>

LEFT\_SLASH\_LINE

</td><td>

`'Left Slash Line'`

</td><td>

</td></tr>
<tr><td>

NONE

</td><td>

`'None'`

</td><td>

</td></tr>
<tr><td>

RHOMBIC\_GRID

</td><td>

`'Rhombic Grid'`

</td><td>

</td></tr>
<tr><td>

RIGHT\_SLASH\_LINE

</td><td>

`'Right Slash Line'`

</td><td>

</td></tr>
<tr><td>

SOLID

</td><td>

`'Solid'`

</td><td>

</td></tr>
<tr><td>

VERTICAL\_LINE

</td><td>

`'Vertical Line'`

</td><td>

</td></tr>
</tbody></table>