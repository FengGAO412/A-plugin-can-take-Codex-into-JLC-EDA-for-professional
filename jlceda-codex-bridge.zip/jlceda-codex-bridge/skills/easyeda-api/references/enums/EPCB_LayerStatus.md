# EPCB\_LayerStatus enum

Layer status

## Signature

```typescript
enum EPCB_LayerStatus
```

## Enumeration Members

<table><thead><tr><th>

Member

</th><th>

Value

</th><th>

Description

</th></tr></thead>
<tbody><tr><td>

HIDDEN

</td><td>

`2`

</td><td>

</td></tr>
<tr><td>

NOT\_USED

</td><td>

`0`

</td><td>

</td></tr>
<tr><td>

SHOW

</td><td>

`1`

</td><td>

</td></tr>
</tbody></table>