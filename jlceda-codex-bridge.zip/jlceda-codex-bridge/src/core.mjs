const DEFAULT_COMPACT_LIMITS = Object.freeze({
  maxDepth: 10,
  maxArrayItems: 30,
  maxObjectKeys: 60,
  maxStringChars: 2_000,
});

export function clampInteger(value, minimum, maximum, fallback) {
  if (!Number.isFinite(value)) {
    return fallback;
  }
  return Math.min(maximum, Math.max(minimum, Math.trunc(value)));
}

function normalizeText(value) {
  return String(value ?? '')
    .replace(/([a-z0-9])([A-Z])/g, '$1 $2')
    .toLowerCase()
    .replace(/[^a-z0-9_.$+\-/\u3400-\u9fff]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

export function tokenizeQuery(query) {
  const parts = String(query ?? '').match(/"[^"]+"|'[^']+'|\S+/g) || [];
  const tokens = [];
  for (const part of parts) {
    const unquoted = part.replace(/^(?:"|')|(?:"|')$/g, '');
    const normalized = normalizeText(unquoted);
    if (!normalized) {
      continue;
    }
    for (const token of normalized.split(' ')) {
      if (token && !tokens.includes(token)) {
        tokens.push(token);
      }
    }
  }
  return tokens;
}

function trimSnippet(lines, start, end, maxChars) {
  const snippet = lines
    .slice(start, end)
    .map((line) => line.trimEnd())
    .join('\n')
    .trim();
  if (snippet.length <= maxChars) {
    return snippet;
  }
  return snippet.slice(0, Math.max(0, maxChars - 18)).trimEnd() + '\n…[excerpt cut]';
}

export function searchDocuments(documents, query, options = {}) {
  const tokens = tokenizeQuery(query);
  if (tokens.length === 0) {
    throw new Error('Query must not be empty.');
  }

  const maxResults = clampInteger(options.maxResults, 1, 20, 8);
  const contextLines = clampInteger(options.contextLines, 0, 3, 1);
  const maxCharsPerResult = clampInteger(options.maxCharsPerResult, 160, 2_000, 700);
  const normalizedPhrase = normalizeText(query);
  const pathPrefix = normalizeText(options.pathPrefix || '');
  const candidates = [];

  for (const document of documents) {
    const fileNormalized = normalizeText(document.file);
    if (pathPrefix && !fileNormalized.includes(pathPrefix)) {
      continue;
    }
    for (let index = 0; index < document.lines.length; index += 1) {
      const line = document.lines[index];
      const lineNormalized = normalizeText(line);
      if (!lineNormalized) {
        continue;
      }
      const combined = fileNormalized + ' ' + lineNormalized;
      const matched = tokens.filter((token) => combined.includes(token));
      if (matched.length === 0) {
        continue;
      }

      const coverage = matched.length / tokens.length;
      let score = Math.round(coverage * 100);
      if (normalizedPhrase && lineNormalized.includes(normalizedPhrase)) score += 180;
      if (normalizedPhrase && fileNormalized.includes(normalizedPhrase)) score += 140;
      if (matched.length === tokens.length) score += 80;
      if (/^#{1,6}\s/.test(line)) score += 35;
      if (/\b(?:function|class|interface|type|enum)\b/i.test(line)) score += 25;
      if (/\w+[.(]\w*/.test(line)) score += 15;
      if (document.file.startsWith('references/classes/')) score += 12;
      if (document.file.startsWith('references/local/')) score += 8;

      candidates.push({
        document,
        index,
        score,
        coverage,
        matched,
      });
    }
  }

  candidates.sort((a, b) =>
    b.score - a.score ||
    b.coverage - a.coverage ||
    a.document.file.localeCompare(b.document.file) ||
    a.index - b.index,
  );

  const selected = [];
  for (const candidate of candidates) {
    const tooClose = selected.some((item) =>
      item.document.file === candidate.document.file &&
      Math.abs(item.index - candidate.index) <= contextLines,
    );
    if (tooClose) {
      continue;
    }
    selected.push(candidate);
    if (selected.length >= maxResults) {
      break;
    }
  }

  return {
    query: String(query),
    terms: tokens,
    candidateCount: candidates.length,
    returned: selected.length,
    results: selected.map((candidate) => {
      const start = Math.max(0, candidate.index - contextLines);
      const end = Math.min(candidate.document.lines.length, candidate.index + contextLines + 1);
      return {
        file: candidate.document.file,
        line: candidate.index + 1,
        coverage: Number(candidate.coverage.toFixed(2)),
        matched: candidate.matched.slice(0, 8),
        excerpt: trimSnippet(candidate.document.lines, start, end, maxCharsPerResult),
      };
    }),
  };
}

function summarizeValue(value, limits, depth = 0, seen = new WeakSet()) {
  if (value === null || typeof value === 'number' || typeof value === 'boolean') {
    return value;
  }
  if (typeof value === 'string') {
    if (value.length <= limits.maxStringChars) return value;
    return value.slice(0, limits.maxStringChars) + `…[${value.length - limits.maxStringChars} chars omitted]`;
  }
  if (typeof value === 'undefined') return '[undefined]';
  if (typeof value === 'bigint') return value.toString();
  if (typeof value === 'function') return '[function]';
  if (depth >= limits.maxDepth) {
    return Array.isArray(value) ? `[array depth limit; ${value.length} items]` : '[object depth limit]';
  }
  if (typeof value !== 'object') return String(value);
  if (seen.has(value)) return '[circular]';
  seen.add(value);

  if (Array.isArray(value)) {
    const result = value
      .slice(0, limits.maxArrayItems)
      .map((item) => summarizeValue(item, limits, depth + 1, seen));
    if (value.length > limits.maxArrayItems) {
      result.push({ __omittedItems: value.length - limits.maxArrayItems });
    }
    return result;
  }

  const result = {};
  const entries = Object.entries(value);
  for (const [key, item] of entries.slice(0, limits.maxObjectKeys)) {
    result[key] = summarizeValue(item, limits, depth + 1, seen);
  }
  if (entries.length > limits.maxObjectKeys) {
    result.__omittedKeys = entries.length - limits.maxObjectKeys;
  }
  return result;
}

function summarizeShape(value, depth = 0) {
  if (value === null || typeof value !== 'object') {
    if (typeof value === 'string' && value.length > 240) {
      return value.slice(0, 240) + `…[${value.length - 240} chars omitted]`;
    }
    return value;
  }
  if (depth >= 4) {
    return Array.isArray(value) ? { type: 'array', length: value.length } : { type: 'object', keys: Object.keys(value).slice(0, 20) };
  }
  if (Array.isArray(value)) {
    return {
      type: 'array',
      length: value.length,
      sample: value.slice(0, 3).map((item) => summarizeShape(item, depth + 1)),
    };
  }
  const keys = Object.keys(value);
  const sample = {};
  for (const key of keys.slice(0, 12)) {
    sample[key] = summarizeShape(value[key], depth + 1);
  }
  if (keys.length > 12) sample.__omittedKeys = keys.length - 12;
  return sample;
}

export function formatToolJson(value, options = {}) {
  const mode = ['compact', 'full', 'summary'].includes(options.mode) ? options.mode : 'compact';
  const maxChars = clampInteger(options.maxChars, 1_000, 100_000, mode === 'full' ? 64_000 : 16_000);
  let prepared = value;
  if (mode === 'summary') {
    prepared = summarizeShape(value);
  }
  else if (mode === 'compact') {
    prepared = summarizeValue(value, {
      ...DEFAULT_COMPACT_LIMITS,
      maxArrayItems: clampInteger(options.maxArrayItems, 1, 200, DEFAULT_COMPACT_LIMITS.maxArrayItems),
    });
  }

  let text = JSON.stringify(prepared);
  if (text.length <= maxChars) {
    return { text, truncated: false, originalChars: text.length };
  }

  const aggressivelyReduced = summarizeValue(prepared, {
    maxDepth: 6,
    maxArrayItems: 8,
    maxObjectKeys: 30,
    maxStringChars: 600,
  });
  const originalChars = JSON.stringify(prepared).length;
  text = JSON.stringify({
    truncated: true,
    originalChars,
    hint: 'Result was structurally reduced to fit the output budget.',
    value: aggressivelyReduced,
  });
  if (text.length <= maxChars) {
    return { text, truncated: true, originalChars };
  }

  const previewBudget = Math.max(200, Math.floor((maxChars - 240) / 2));
  return {
    text: JSON.stringify({
      truncated: true,
      originalChars,
      hint: 'Narrow the query, lower sampleLimit, or request outputMode="full" with a larger maxOutputChars.',
      preview: text.slice(0, previewBudget),
    }),
    truncated: true,
    originalChars,
  };
}

export function buildGuardedCode(code, guard = {}) {
  const checks = [];
  if (guard.projectUuid) {
    checks.push(`const __codexBridgeProject = await eda.dmt_Project.getCurrentProjectInfo();`);
    checks.push(`if (__codexBridgeProject?.uuid !== ${JSON.stringify(guard.projectUuid)}) throw new Error('Project guard failed: expected ' + ${JSON.stringify(guard.projectUuid)} + ', got ' + (__codexBridgeProject?.uuid || 'none'));`);
  }
  if (guard.documentUuid || guard.documentType !== undefined) {
    checks.push(`const __codexBridgeDocument = await eda.dmt_SelectControl.getCurrentDocumentInfo();`);
    if (guard.documentUuid) {
      checks.push(`if (__codexBridgeDocument?.uuid !== ${JSON.stringify(guard.documentUuid)}) throw new Error('Document guard failed: expected ' + ${JSON.stringify(guard.documentUuid)} + ', got ' + (__codexBridgeDocument?.uuid || 'none'));`);
    }
    if (guard.documentType !== undefined) {
      checks.push(`if (__codexBridgeDocument?.documentType !== ${Number(guard.documentType)}) throw new Error('Document type guard failed: expected ${Number(guard.documentType)}, got ' + (__codexBridgeDocument?.documentType ?? 'none'));`);
    }
  }
  return checks.length ? checks.join('\n') + '\n' + code : code;
}
