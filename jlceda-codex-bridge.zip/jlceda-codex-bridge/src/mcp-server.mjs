import { existsSync, readdirSync, readFileSync, statSync } from 'node:fs';
import { createServer, get as httpGet } from 'node:http';
import { createConnection } from 'node:net';
import { dirname, join, relative } from 'node:path';
import { fileURLToPath } from 'node:url';
import { randomUUID } from 'node:crypto';
import { spawn } from 'node:child_process';
import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { CallToolRequestSchema, ListToolsRequestSchema } from '@modelcontextprotocol/sdk/types.js';
import { WebSocketServer } from 'ws';
import {
  buildGuardedCode,
  clampInteger,
  formatToolJson,
  searchDocuments,
} from './core.mjs';

const SERVICE_ID = 'easyeda-bridge';
const LISTEN_HOST = '127.0.0.1';
const PORT_START = 49620;
const PORT_END = 49629;
const REQUEST_TIMEOUT_MS = 30_000;
const MIN_REQUEST_TIMEOUT_MS = 5_000;
const MAX_REQUEST_TIMEOUT_MS = 120_000;
const REQUEST_HISTORY_TTL_MS = 15 * 60_000;
const REQUEST_LATE_RESULT_GRACE_MS = 2 * 60_000;
const MAX_REQUEST_HISTORY = 100;
const MAX_HTTP_BODY_BYTES = 1024 * 1024;
const DEFAULT_APP_PATH = 'D:\\Installation\\lceda-pro\\lceda-pro.exe';
const SOURCE_DIR = dirname(fileURLToPath(import.meta.url));
const PLUGIN_ROOT = dirname(SOURCE_DIR);
const SKILL_ROOT = join(PLUGIN_ROOT, 'skills', 'easyeda-api');

const bridgeState = {
  activeWindowId: null,
  edaClients: new Map(),
  httpServer: null,
  mode: null,
  pendingRequests: new Map(),
  requestHistory: new Map(),
  port: null,
  wss: null,
};

function log(message) {
  process.stderr.write('[jlceda-codex-bridge] ' + message + '\n');
}

function jsonText(value, isError = false, outputOptions = {}) {
  const formatted = formatToolJson(value, outputOptions);
  return {
    content: [{ type: 'text', text: formatted.text }],
    isError,
  };
}

function errorText(error) {
  return jsonText({
    error: error instanceof Error ? error.message : String(error),
    ...(error?.details ? { details: error.details } : {}),
    ...(error?.requestId ? { requestId: error.requestId, outcome: error.outcome || 'unknown' } : {}),
  }, true);
}

class BridgeRequestTimeoutError extends Error {
  constructor(requestId, timeoutMs) {
    super('EDA request timed out after ' + timeoutMs + ' ms. The execution outcome is unknown; call request_status before retrying.');
    this.name = 'BridgeRequestTimeoutError';
    this.requestId = requestId;
    this.outcome = 'unknown';
  }
}

function isPortInUse(port) {
  return new Promise((resolve) => {
    const socket = createConnection({ port, host: LISTEN_HOST });
    socket.setTimeout(300);
    socket.once('connect', () => {
      socket.destroy();
      resolve(true);
    });
    socket.once('timeout', () => {
      socket.destroy();
      resolve(false);
    });
    socket.once('error', () => {
      socket.destroy();
      resolve(false);
    });
  });
}

function probeBridge(port) {
  return new Promise((resolve) => {
    const req = httpGet('http://' + LISTEN_HOST + ':' + port + '/health', { timeout: 800 }, (res) => {
      let body = '';
      res.setEncoding('utf8');
      res.on('data', (chunk) => {
        body += chunk;
      });
      res.on('end', () => {
        try {
          const data = JSON.parse(body);
          resolve(data.service === SERVICE_ID ? data : null);
        }
        catch {
          resolve(null);
        }
      });
    });
    req.once('error', () => resolve(null));
    req.once('timeout', () => {
      req.destroy();
      resolve(null);
    });
  });
}

async function findExistingBridge() {
  for (let port = PORT_START; port <= PORT_END; port += 1) {
    const health = await probeBridge(port);
    if (health) {
      return { port, health };
    }
  }
  return null;
}

async function findAvailablePort() {
  for (let port = PORT_START; port <= PORT_END; port += 1) {
    if (!(await isPortInUse(port))) {
      return port;
    }
  }
  throw new Error('All EasyEDA bridge ports ' + PORT_START + '-' + PORT_END + ' are occupied.');
}

function readJsonBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.setEncoding('utf8');
    req.on('data', (chunk) => {
      body += chunk;
      if (Buffer.byteLength(body, 'utf8') > MAX_HTTP_BODY_BYTES) {
        reject(new Error('Request body is too large.'));
        req.destroy();
      }
    });
    req.on('end', () => {
      try {
        resolve(JSON.parse(body || '{}'));
      }
      catch {
        reject(new Error('Invalid JSON request body.'));
      }
    });
    req.on('error', reject);
  });
}

function writeJson(res, statusCode, value) {
  res.writeHead(statusCode, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
  });
  res.end(JSON.stringify(value));
}

function listEmbeddedWindows() {
  const windows = [];
  for (const [windowId, ws] of bridgeState.edaClients) {
    windows.push({
      windowId,
      connected: ws.readyState === 1,
      active: windowId === bridgeState.activeWindowId,
    });
  }
  return {
    windows,
    activeWindowId: bridgeState.activeWindowId,
    count: windows.length,
  };
}

function sendToEda(windowId, message) {
  const client = bridgeState.edaClients.get(windowId);
  if (!client || client.readyState !== 1) {
    throw new Error('EDA window "' + windowId + '" is not connected.');
  }
  client.send(JSON.stringify(message));
}

function pruneRequestHistory() {
  const now = Date.now();
  for (const [id, item] of bridgeState.requestHistory) {
    if (now - item.updatedAt > REQUEST_HISTORY_TTL_MS) {
      bridgeState.requestHistory.delete(id);
    }
  }
  while (bridgeState.requestHistory.size > MAX_REQUEST_HISTORY) {
    bridgeState.requestHistory.delete(bridgeState.requestHistory.keys().next().value);
  }
}

function getRequestStatus(requestId) {
  pruneRequestHistory();
  const item = bridgeState.requestHistory.get(requestId);
  if (!item) {
    return { found: false, requestId };
  }
  return { found: true, requestId, ...item };
}

function executeEmbedded(code, requestedWindowId, requestedTimeoutMs) {
  return new Promise((resolve, reject) => {
    const windowId = requestedWindowId || bridgeState.activeWindowId;
    if (!windowId) {
      reject(new Error('No 嘉立创EDA window is connected. Install and enable run-api-gateway.eext, then reopen 嘉立创EDA.'));
      return;
    }
    if (!bridgeState.edaClients.has(windowId)) {
      reject(new Error('EDA window "' + windowId + '" is no longer connected.'));
      return;
    }

    const id = randomUUID();
    const timeoutMs = clampInteger(requestedTimeoutMs, MIN_REQUEST_TIMEOUT_MS, MAX_REQUEST_TIMEOUT_MS, REQUEST_TIMEOUT_MS);
    const startedAt = Date.now();
    bridgeState.requestHistory.set(id, {
      status: 'running',
      windowId,
      startedAt,
      updatedAt: startedAt,
    });
    const timer = setTimeout(() => {
      const pending = bridgeState.pendingRequests.get(id);
      if (!pending) return;
      pending.settled = true;
      bridgeState.requestHistory.set(id, {
        status: 'timed_out',
        outcome: 'unknown',
        windowId,
        startedAt,
        updatedAt: Date.now(),
        timeoutMs,
      });
      pending.graceTimer = setTimeout(() => {
        bridgeState.pendingRequests.delete(id);
      }, REQUEST_LATE_RESULT_GRACE_MS);
      reject(new BridgeRequestTimeoutError(id, timeoutMs));
    }, timeoutMs);

    bridgeState.pendingRequests.set(id, { resolve, reject, timer, graceTimer: null, settled: false, startedAt, timeoutMs, windowId });
    try {
      sendToEda(windowId, {
        type: 'execute',
        id,
        code,
        windowId,
        timestamp: Date.now(),
      });
    }
    catch (error) {
      clearTimeout(timer);
      bridgeState.pendingRequests.delete(id);
      reject(error);
    }
  });
}

function handleEdaMessage(message, windowId) {
  if (message.type === 'ping') {
    sendToEda(windowId, { type: 'pong', id: message.id, timestamp: Date.now() });
    return;
  }
  if (message.type === 'pong') {
    return;
  }
  if (message.type !== 'result' && message.type !== 'error') {
    return;
  }

  const pending = bridgeState.pendingRequests.get(message.id);
  if (!pending) {
    return;
  }
  clearTimeout(pending.timer);
  if (pending.graceTimer) clearTimeout(pending.graceTimer);
  bridgeState.pendingRequests.delete(message.id);
  const updatedAt = Date.now();
  if (message.type === 'result') {
    bridgeState.requestHistory.set(message.id, {
      status: 'completed',
      outcome: 'completed',
      windowId,
      startedAt: pending.startedAt,
      updatedAt,
      durationMs: updatedAt - pending.startedAt,
      result: message.result,
    });
    if (!pending.settled) pending.resolve({ requestId: message.id, result: message.result });
  }
  else {
    const errorMessage = message.error || 'Unknown 嘉立创EDA error.';
    bridgeState.requestHistory.set(message.id, {
      status: 'error',
      outcome: 'error',
      windowId,
      startedAt: pending.startedAt,
      updatedAt,
      durationMs: updatedAt - pending.startedAt,
      error: errorMessage,
    });
    if (!pending.settled) pending.reject(new Error(errorMessage));
  }
  pruneRequestHistory();
}

function rejectWindowRequests(windowId) {
  for (const [id, pending] of bridgeState.pendingRequests) {
    if (pending.windowId === windowId) {
      clearTimeout(pending.timer);
      if (pending.graceTimer) clearTimeout(pending.graceTimer);
      pending.reject(new Error('EDA window "' + windowId + '" disconnected.'));
      bridgeState.pendingRequests.delete(id);
      bridgeState.requestHistory.set(id, {
        status: 'error',
        outcome: 'disconnected',
        windowId,
        startedAt: pending.startedAt,
        updatedAt: Date.now(),
        error: 'EDA window disconnected.',
      });
    }
  }
}

function createEmbeddedHttpServer() {
  return createServer(async (req, res) => {
    try {
      if (req.method === 'GET' && req.url === '/health') {
        writeJson(res, 200, {
          service: SERVICE_ID,
          status: 'ok',
          implementation: 'jlceda-codex-bridge',
          edaConnected: bridgeState.edaClients.size > 0,
          edaWindowCount: bridgeState.edaClients.size,
          activeWindowId: bridgeState.activeWindowId,
          pendingRequests: bridgeState.pendingRequests.size,
          timestamp: Date.now(),
        });
        return;
      }

      if (req.method === 'GET' && req.url === '/eda-windows') {
        writeJson(res, 200, listEmbeddedWindows());
        return;
      }

      if (req.method === 'POST' && req.url === '/eda-windows/select') {
        const payload = await readJsonBody(req);
        if (!payload.windowId || !bridgeState.edaClients.has(payload.windowId)) {
          writeJson(res, 404, { error: 'EDA window not found.' });
          return;
        }
        bridgeState.activeWindowId = payload.windowId;
        writeJson(res, 200, { success: true, activeWindowId: payload.windowId });
        return;
      }

      if (req.method === 'POST' && req.url === '/execute') {
        const payload = await readJsonBody(req);
        if (typeof payload.code !== 'string' || !payload.code.trim()) {
          writeJson(res, 400, { success: false, error: 'The code field must be a non-empty string.' });
          return;
        }
        const execution = await executeEmbedded(payload.code, payload.windowId, payload.timeoutMs);
        writeJson(res, 200, {
          success: true,
          requestId: execution.requestId,
          result: execution.result,
          windowId: payload.windowId || bridgeState.activeWindowId,
        });
        return;
      }

      writeJson(res, 404, { error: 'Not found.' });
    }
    catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      writeJson(res, message.includes('connected') ? 503 : 500, {
        success: false,
        error: message,
        ...(error?.requestId ? { requestId: error.requestId, outcome: error.outcome || 'unknown' } : {}),
      });
    }
  });
}

async function startEmbeddedBridge() {
  const port = await findAvailablePort();
  const httpServer = createEmbeddedHttpServer();
  const wss = new WebSocketServer({ server: httpServer });

  wss.on('connection', (ws, req) => {
    if (req.url !== '/eda') {
      ws.close(1008, 'Only EasyEDA extension connections are accepted.');
      return;
    }

    let registeredWindowId = null;
    ws.send(JSON.stringify({
      type: 'handshake',
      service: SERVICE_ID,
      clientType: 'eda',
      timestamp: Date.now(),
    }));

    ws.on('message', (raw) => {
      try {
        const message = JSON.parse(raw.toString());
        if (message.type === 'register' && typeof message.windowId === 'string') {
          registeredWindowId = message.windowId;
          bridgeState.edaClients.set(registeredWindowId, ws);
          if (!bridgeState.activeWindowId) {
            bridgeState.activeWindowId = registeredWindowId;
          }
          log('嘉立创EDA window connected: ' + registeredWindowId);
          return;
        }
        if (registeredWindowId) {
          handleEdaMessage(message, registeredWindowId);
        }
      }
      catch (error) {
        log('Ignored invalid EDA bridge message: ' + (error instanceof Error ? error.message : String(error)));
      }
    });

    ws.on('close', () => {
      if (!registeredWindowId) {
        return;
      }
      bridgeState.edaClients.delete(registeredWindowId);
      rejectWindowRequests(registeredWindowId);
      if (bridgeState.activeWindowId === registeredWindowId) {
        bridgeState.activeWindowId = bridgeState.edaClients.keys().next().value || null;
      }
      log('嘉立创EDA window disconnected: ' + registeredWindowId);
    });

    ws.on('error', (error) => {
      log('EDA WebSocket error: ' + error.message);
    });
  });

  await new Promise((resolve, reject) => {
    httpServer.once('error', reject);
    httpServer.listen(port, LISTEN_HOST, () => {
      httpServer.off('error', reject);
      resolve();
    });
  });

  bridgeState.httpServer = httpServer;
  bridgeState.mode = 'embedded';
  bridgeState.port = port;
  bridgeState.wss = wss;
  log('Embedded EasyEDA bridge listening on ' + LISTEN_HOST + ':' + port);
}

async function ensureBridge() {
  if (bridgeState.mode === 'embedded' && bridgeState.httpServer?.listening) {
    return;
  }

  if (bridgeState.mode === 'proxy' && bridgeState.port) {
    if (await probeBridge(bridgeState.port)) {
      return;
    }
    bridgeState.mode = null;
    bridgeState.port = null;
  }

  const existing = await findExistingBridge();
  if (existing) {
    bridgeState.mode = 'proxy';
    bridgeState.port = existing.port;
    log('Using existing EasyEDA bridge on port ' + existing.port);
    return;
  }

  await startEmbeddedBridge();
}

async function bridgeRequest(method, path, payload) {
  await ensureBridge();
  const options = { method, headers: {} };
  if (payload !== undefined) {
    options.headers['Content-Type'] = 'application/json';
    options.body = JSON.stringify(payload);
  }
  const response = await fetch('http://' + LISTEN_HOST + ':' + bridgeState.port + path, options);
  const text = await response.text();
  let data;
  try {
    data = JSON.parse(text);
  }
  catch {
    data = { raw: text };
  }
  if (!response.ok) {
    const error = new Error(data.error || ('Bridge request failed with HTTP ' + response.status + '.'));
    error.details = data;
    if (data.requestId) {
      error.requestId = data.requestId;
      error.outcome = data.outcome || 'unknown';
    }
    throw error;
  }
  return data;
}

function launchJlcEda() {
  const appPath = process.env.JLCEDA_PRO_EXE || DEFAULT_APP_PATH;
  if (!existsSync(appPath)) {
    throw new Error('嘉立创EDA executable was not found at ' + appPath + '.');
  }
  const child = spawn(appPath, [], {
    detached: true,
    stdio: 'ignore',
    windowsHide: false,
  });
  child.unref();
  return { launched: true, executable: appPath, pid: child.pid };
}

function collectSearchFiles(root, files = []) {
  if (!existsSync(root)) {
    return files;
  }
  for (const entry of readdirSync(root, { withFileTypes: true })) {
    const fullPath = join(root, entry.name);
    if (entry.isDirectory()) {
      collectSearchFiles(fullPath, files);
    }
    else if (entry.isFile() && (entry.name.endsWith('.md') || entry.name.endsWith('.d.ts'))) {
      files.push(fullPath);
    }
  }
  return files;
}

let apiSearchDocuments = null;

function getApiSearchDocuments() {
  if (apiSearchDocuments) {
    return apiSearchDocuments;
  }
  const roots = [
    { root: join(SKILL_ROOT, 'references'), scope: 'api' },
    { root: join(SKILL_ROOT, 'format'), scope: 'format' },
    { root: join(SKILL_ROOT, 'guide'), scope: 'guide' },
  ];
  apiSearchDocuments = [];
  for (const item of roots) {
    for (const file of collectSearchFiles(item.root)) {
      if (statSync(file).size > 2 * 1024 * 1024) {
        continue;
      }
      apiSearchDocuments.push({
        file: relative(SKILL_ROOT, file).replaceAll('\\', '/'),
        scope: item.scope,
        lines: readFileSync(file, 'utf8').split(/\r?\n/),
      });
    }
  }
  return apiSearchDocuments;
}

function searchApiDocs(query, options = {}) {
  const scope = ['api', 'format', 'guide', 'all'].includes(options.scope) ? options.scope : 'api';
  const documents = getApiSearchDocuments().filter((document) => scope === 'all' || document.scope === scope);
  return {
    scope,
    ...searchDocuments(documents, query, options),
  };
}

function outputOptionsFromArgs(args, defaults = {}) {
  return {
    mode: args.outputMode || defaults.mode || 'compact',
    maxChars: args.maxOutputChars || defaults.maxChars,
    maxArrayItems: args.maxArrayItems || defaults.maxArrayItems,
  };
}

function buildContextCode(detail) {
  if (detail === 'full') {
    return 'const project = await eda.dmt_Project.getCurrentProjectInfo(); const document = await eda.dmt_SelectControl.getCurrentDocumentInfo(); return { project, document };';
  }
  return `
const project = await eda.dmt_Project.getCurrentProjectInfo();
const document = await eda.dmt_SelectControl.getCurrentDocumentInfo();
const items = Array.isArray(project?.data) ? project.data : [];
const boards = items.filter(item => item?.itemType === 'Board').map(board => ({
  name: board.name,
  schematic: board.schematic ? {
    uuid: board.schematic.uuid,
    name: board.schematic.name,
    pages: (board.schematic.page || []).map(page => ({ uuid: page.uuid, name: page.name })),
  } : null,
  pcb: board.pcb ? { uuid: board.pcb.uuid, name: board.pcb.name } : null,
}));
return {
  project: project ? {
    uuid: project.uuid,
    friendlyName: project.friendlyName,
    name: project.name,
    teamUuid: project.teamUuid,
    boards,
    nonBoardItems: items.filter(item => item?.itemType !== 'Board').map(item => ({ itemType: item.itemType, uuid: item.uuid, name: item.name })),
  } : null,
  document,
};`;
}

function buildInspectDesignCode(args) {
  const sampleLimit = clampInteger(args.sampleLimit, 0, 50, 10);
  const includeDrc = args.includeDrc !== false;
  const strict = args.strict !== false;
  return `
const document = await eda.dmt_SelectControl.getCurrentDocumentInfo();
const sampleLimit = ${sampleLimit};
const includeDrc = ${includeDrc};
const strict = ${strict};
const countBy = (items, getter) => {
  const result = {};
  for (const item of items) {
    const key = String(getter(item) ?? '');
    result[key] = (result[key] || 0) + 1;
  }
  return result;
};
if (document?.documentType === 1) {
  const components = await eda.sch_PrimitiveComponent.getAll();
  const wires = await eda.sch_PrimitiveWire.getAll();
  const markers = components.filter(item => ['netport', 'netflag'].includes(item.getState_ComponentType?.()));
  const endpoints = [];
  const vertices = new Map();
  let emptyNetWires = 0;
  for (const wire of wires) {
    const net = wire.getState_Net?.() || '';
    if (!net) emptyNetWires += 1;
    const raw = wire.getState_Line?.();
    const lines = Array.isArray(raw?.[0]) ? raw : [raw];
    for (const line of lines) {
      if (!Array.isArray(line) || line.length < 4) continue;
      const points = [];
      for (let index = 0; index < line.length; index += 2) points.push([line[index], line[index + 1]]);
      endpoints.push({ net, x: points[0][0], y: points[0][1] });
      const lastPoint = points[points.length - 1];
      endpoints.push({ net, x: lastPoint[0], y: lastPoint[1] });
      for (const point of points) {
        const key = Number(point[0]).toFixed(6) + ',' + Number(point[1]).toFixed(6);
        if (!vertices.has(key)) vertices.set(key, new Set());
        if (net) vertices.get(key).add(net);
      }
    }
  }
  const markerData = markers.map(marker => ({
    id: marker.getState_PrimitiveId(),
    type: marker.getState_ComponentType(),
    net: marker.getState_Net?.() || '',
    x: marker.getState_X(),
    y: marker.getState_Y(),
    rotation: marker.getState_Rotation?.() ?? 0,
  }));
  const markerGroups = new Map();
  for (const marker of markerData) {
    const key = Number(marker.x).toFixed(6) + ',' + Number(marker.y).toFixed(6);
    if (!markerGroups.has(key)) markerGroups.set(key, []);
    markerGroups.get(key).push(marker);
  }
  const mismatchedMarkers = [];
  for (const marker of markerData) {
    const attachedNets = [...new Set(endpoints
      .filter(endpoint => Math.abs(endpoint.x - marker.x) < 1e-6 && Math.abs(endpoint.y - marker.y) < 1e-6 && endpoint.net)
      .map(endpoint => endpoint.net))];
    if (attachedNets.length === 1 && marker.net !== attachedNets[0]) {
      mismatchedMarkers.push({ ...marker, attachedNet: attachedNets[0] });
    }
  }
  const duplicateMarkers = [...markerGroups.entries()]
    .filter(([, items]) => items.length > 1)
    .map(([coordinate, items]) => ({ coordinate, nets: items.map(item => item.net), ids: items.map(item => item.id) }));
  const multiNetVertices = [...vertices.entries()]
    .filter(([, nets]) => nets.size > 1)
    .map(([coordinate, nets]) => ({ coordinate, nets: [...nets] }));
  const drc = includeDrc ? await eda.sch_Drc.check(strict, false, true) : null;
  return {
    kind: 'schematic',
    document,
    counts: {
      components: components.length,
      componentTypes: countBy(components, item => item.getState_ComponentType?.()),
      wires: wires.length,
      markers: markerData.length,
      emptyNetWires,
    },
    nets: {
      markers: countBy(markerData, item => item.net),
      wires: countBy(wires, item => item.getState_Net?.() || ''),
    },
    issues: {
      mismatchedMarkers: { count: mismatchedMarkers.length, samples: mismatchedMarkers.slice(0, sampleLimit) },
      duplicateMarkers: { count: duplicateMarkers.length, samples: duplicateMarkers.slice(0, sampleLimit) },
      multiNetVertices: { count: multiNetVertices.length, samples: multiNetVertices.slice(0, sampleLimit) },
    },
    drc,
  };
}
if (document?.documentType === 3) {
  const [components, lines, vias, pours, regions, nets] = await Promise.all([
    eda.pcb_PrimitiveComponent.getAll(),
    eda.pcb_PrimitiveLine.getAll(),
    eda.pcb_PrimitiveVia.getAll(),
    eda.pcb_PrimitivePour.getAll(),
    eda.pcb_PrimitiveRegion.getAll(),
    eda.pcb_Net.getAllNets(),
  ]);
  const drc = includeDrc ? await eda.pcb_Drc.check(strict, false, true) : null;
  return {
    kind: 'pcb',
    document,
    counts: {
      components: components.length,
      lines: lines.length,
      vias: vias.length,
      pours: pours.length,
      regions: regions.length,
      nets: nets.length,
    },
    lineNets: countBy(lines, item => item.getState_Net?.() || ''),
    componentSamples: components.slice(0, sampleLimit).map(item => ({
      id: item.getState_PrimitiveId?.(),
      designator: item.getState_Designator?.(),
      x: item.getState_X?.(),
      y: item.getState_Y?.(),
      layer: item.getState_Layer?.(),
    })),
    drc,
  };
}
return { kind: 'unsupported', document, error: 'Open a schematic page or PCB document before inspection.' };
`;
}

const tools = [
  {
    name: 'status',
    title: '嘉立创EDA bridge status',
    description: 'Check the local bridge, installed 嘉立创EDA executable, connected EDA windows, and packaged gateway extension.',
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
    annotations: { readOnlyHint: true, openWorldHint: false },
  },
  {
    name: 'launch',
    title: 'Launch 嘉立创EDA',
    description: 'Launch D:\\Installation\\lceda-pro\\lceda-pro.exe. The gateway extension must already be imported and enabled.',
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
    annotations: { readOnlyHint: false, openWorldHint: false },
  },
  {
    name: 'list_windows',
    title: 'List 嘉立创EDA windows',
    description: 'List EDA windows connected through the official Run API Gateway extension.',
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
    annotations: { readOnlyHint: true, openWorldHint: false },
  },
  {
    name: 'select_window',
    title: 'Select 嘉立创EDA window',
    description: 'Choose the active EDA window for later context and API calls.',
    inputSchema: {
      type: 'object',
      properties: { windowId: { type: 'string', minLength: 1 } },
      required: ['windowId'],
      additionalProperties: false,
    },
    annotations: { readOnlyHint: false, openWorldHint: false },
  },
  {
    name: 'get_context',
    title: 'Get current 嘉立创EDA context',
    description: 'Read a token-efficient project/document summary. Request detail="full" only when title-block and raw project fields are necessary.',
    inputSchema: {
      type: 'object',
      properties: {
        windowId: { type: 'string' },
        detail: { type: 'string', enum: ['summary', 'full'], default: 'summary' },
        outputMode: { type: 'string', enum: ['compact', 'full', 'summary'], default: 'compact' },
        maxOutputChars: { type: 'integer', minimum: 1000, maximum: 100000, default: 16000 },
      },
      additionalProperties: false,
    },
    annotations: { readOnlyHint: true, openWorldHint: false },
  },
  {
    name: 'inspect_design',
    title: 'Inspect current schematic or PCB',
    description: 'Run a compact read-only audit of the active schematic or PCB, including counts, bounded samples, connectivity issues, and optional ERC/DRC.',
    inputSchema: {
      type: 'object',
      properties: {
        windowId: { type: 'string' },
        includeDrc: { type: 'boolean', default: true },
        strict: { type: 'boolean', default: true },
        sampleLimit: { type: 'integer', minimum: 0, maximum: 50, default: 10 },
        timeoutMs: { type: 'integer', minimum: 5000, maximum: 120000, default: 30000 },
        outputMode: { type: 'string', enum: ['compact', 'full', 'summary'], default: 'compact' },
        maxOutputChars: { type: 'integer', minimum: 1000, maximum: 100000, default: 16000 },
      },
      additionalProperties: false,
    },
    annotations: { readOnlyHint: true, openWorldHint: false },
  },
  {
    name: 'execute',
    title: 'Execute 嘉立创EDA API code',
    description: 'Execute documented extension API code with optional project/document guards, configurable timeout, and bounded output. Return only fields needed for the next decision.',
    inputSchema: {
      type: 'object',
      properties: {
        code: { type: 'string', minLength: 1, description: 'Function body executed as async function(eda). Include return to receive a result.' },
        windowId: { type: 'string', description: 'Optional connected EDA window ID.' },
        guard: {
          type: 'object',
          properties: {
            projectUuid: { type: 'string' },
            documentUuid: { type: 'string' },
            documentType: { type: 'integer', enum: [1, 3], description: '1 = schematic page, 3 = PCB.' },
          },
          additionalProperties: false,
          description: 'Optional pre-execution context guard. The call fails before user code runs when the active target differs.',
        },
        timeoutMs: { type: 'integer', minimum: 5000, maximum: 120000, default: 30000 },
        outputMode: { type: 'string', enum: ['compact', 'full', 'summary'], default: 'compact' },
        maxOutputChars: { type: 'integer', minimum: 1000, maximum: 100000, default: 16000 },
        maxArrayItems: { type: 'integer', minimum: 1, maximum: 200, default: 30 },
      },
      required: ['code'],
      additionalProperties: false,
    },
    annotations: { readOnlyHint: false, destructiveHint: true, openWorldHint: false },
  },
  {
    name: 'search_api',
    title: 'Search 嘉立创EDA API reference',
    description: 'Search the bundled official API docs, exact local 0.2.53 type snapshot, guides, and document-format references.',
    inputSchema: {
      type: 'object',
      properties: {
        query: { type: 'string', minLength: 1 },
        scope: { type: 'string', enum: ['api', 'format', 'guide', 'all'], default: 'api' },
        pathPrefix: { type: 'string', description: 'Optional relative path filter such as references/classes or references/enums.' },
        maxResults: { type: 'integer', minimum: 1, maximum: 20, default: 8 },
        contextLines: { type: 'integer', minimum: 0, maximum: 3, default: 1 },
        maxCharsPerResult: { type: 'integer', minimum: 160, maximum: 2000, default: 700 },
      },
      required: ['query'],
      additionalProperties: false,
    },
    annotations: { readOnlyHint: true, openWorldHint: false },
  },
  {
    name: 'request_status',
    title: 'Check a timed-out local EDA request',
    description: 'Check whether a timed-out request later completed. Available only when this MCP process owns the embedded bridge; otherwise inspect design state before retrying.',
    inputSchema: {
      type: 'object',
      properties: { requestId: { type: 'string', minLength: 1 } },
      required: ['requestId'],
      additionalProperties: false,
    },
    annotations: { readOnlyHint: true, openWorldHint: false },
  },
];

const mcpServer = new Server(
  { name: 'jlceda-codex-bridge', title: '嘉立创EDA Codex Bridge', version: '0.1.0' },
  {
    capabilities: { tools: {} },
    instructions: 'Use compact get_context and inspect_design first. Search exact API symbols with search_api before execute. For mutations, pass project/document guards, return bounded summaries, and verify by readback.',
  },
);

mcpServer.setRequestHandler(ListToolsRequestSchema, async () => ({ tools }));

mcpServer.setRequestHandler(CallToolRequestSchema, async (request) => {
  const args = request.params.arguments || {};
  try {
    switch (request.params.name) {
      case 'status': {
        await ensureBridge();
        const health = await bridgeRequest('GET', '/health');
        return jsonText({
          ...health,
          bridgeMode: bridgeState.mode,
          bridgePort: bridgeState.port,
          executable: process.env.JLCEDA_PRO_EXE || DEFAULT_APP_PATH,
          executableFound: existsSync(process.env.JLCEDA_PRO_EXE || DEFAULT_APP_PATH),
          gatewayExtension: join(PLUGIN_ROOT, 'assets', 'run-api-gateway_v1.0.5.eext'),
          gatewayExtensionFound: existsSync(join(PLUGIN_ROOT, 'assets', 'run-api-gateway_v1.0.5.eext')),
        });
      }
      case 'launch':
        await ensureBridge();
        return jsonText(launchJlcEda());
      case 'list_windows':
        return jsonText(await bridgeRequest('GET', '/eda-windows'));
      case 'select_window':
        return jsonText(await bridgeRequest('POST', '/eda-windows/select', { windowId: args.windowId }));
      case 'get_context': {
        const code = buildContextCode(args.detail || 'summary');
        const response = await bridgeRequest('POST', '/execute', { code, windowId: args.windowId });
        return jsonText(response, false, outputOptionsFromArgs(args, { maxChars: 16000 }));
      }
      case 'inspect_design': {
        const response = await bridgeRequest('POST', '/execute', {
          code: buildInspectDesignCode(args),
          windowId: args.windowId,
          timeoutMs: args.timeoutMs,
        });
        return jsonText(response, false, outputOptionsFromArgs(args, { maxChars: 16000 }));
      }
      case 'execute': {
        if (!/\breturn\b/.test(args.code)) {
          throw new Error('The execute code must include an explicit return value. Return a compact JSON-serializable summary.');
        }
        const code = buildGuardedCode(args.code, args.guard || {});
        const response = await bridgeRequest('POST', '/execute', {
          code,
          windowId: args.windowId,
          timeoutMs: args.timeoutMs,
        });
        return jsonText(response, false, outputOptionsFromArgs(args, { maxChars: 16000, maxArrayItems: 30 }));
      }
      case 'search_api':
        return jsonText(searchApiDocs(args.query, {
          scope: args.scope,
          pathPrefix: args.pathPrefix,
          maxResults: args.maxResults,
          contextLines: args.contextLines,
          maxCharsPerResult: args.maxCharsPerResult,
        }), false, { mode: 'compact', maxChars: 16000, maxArrayItems: 20 });
      case 'request_status':
        if (bridgeState.mode !== 'embedded') {
          return jsonText({
            found: false,
            requestId: args.requestId,
            reason: 'This MCP process is using a shared proxy bridge. Inspect the design state before retrying the operation.',
          });
        }
        return jsonText(getRequestStatus(args.requestId), false, { mode: 'compact', maxChars: 16000, maxArrayItems: 30 });
      default:
        return errorText(new Error('Unknown tool: ' + request.params.name));
    }
  }
  catch (error) {
    return errorText(error);
  }
});

async function shutdown() {
  for (const pending of bridgeState.pendingRequests.values()) {
    clearTimeout(pending.timer);
    if (pending.graceTimer) clearTimeout(pending.graceTimer);
    pending.reject(new Error('Bridge is shutting down.'));
  }
  bridgeState.pendingRequests.clear();
  bridgeState.requestHistory.clear();
  if (bridgeState.wss) {
    bridgeState.wss.close();
  }
  if (bridgeState.httpServer?.listening) {
    await new Promise((resolve) => bridgeState.httpServer.close(resolve));
  }
  await mcpServer.close();
}

let shuttingDown = false;
function requestShutdown() {
  if (shuttingDown) {
    return;
  }
  shuttingDown = true;
  const forceExitTimer = setTimeout(() => process.exit(0), 1500);
  void shutdown().finally(() => process.exit(0));
}

await ensureBridge();
await mcpServer.connect(new StdioServerTransport());
process.stdin.once('close', requestShutdown);
process.stdin.once('end', requestShutdown);
process.once('SIGINT', requestShutdown);
process.once('SIGTERM', requestShutdown);
