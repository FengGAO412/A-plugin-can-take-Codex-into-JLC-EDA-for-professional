import test from 'node:test';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { StdioClientTransport } from '@modelcontextprotocol/sdk/client/stdio.js';

const pluginRoot = dirname(dirname(fileURLToPath(import.meta.url)));

test('built MCP server exposes efficient tools and compact ranked search', { timeout: 20_000 }, async () => {
  const transport = new StdioClientTransport({
    command: process.execPath,
    args: [join(pluginRoot, 'server', 'server.mjs')],
    cwd: pluginRoot,
    stderr: 'pipe',
  });
  const client = new Client({ name: 'jlceda-bridge-smoke-test', version: '1.0.0' });
  try {
    await client.connect(transport);
    const listed = await client.listTools();
    const names = listed.tools.map((tool) => tool.name);
    assert.ok(names.includes('get_context'));
    assert.ok(names.includes('inspect_design'));
    assert.ok(names.includes('execute'));
    assert.ok(names.includes('search_api'));
    assert.ok(names.includes('request_status'));

    const search = await client.callTool({
      name: 'search_api',
      arguments: {
        query: 'SCH_PrimitiveComponent.createNetPort',
        scope: 'api',
        maxResults: 3,
        contextLines: 1,
      },
    });
    const text = search.content[0].text;
    const payload = JSON.parse(text);
    assert.equal(payload.scope, 'api');
    assert.ok(payload.returned > 0);
    assert.ok(payload.returned <= 3);
    assert.ok(payload.results.some((item) => item.file.includes('SCH_PrimitiveComponent')));
    assert.ok(text.length < 8_000);
  }
  finally {
    await client.close();
  }
});
