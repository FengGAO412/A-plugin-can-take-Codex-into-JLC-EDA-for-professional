import test from 'node:test';
import assert from 'node:assert/strict';
import {
  buildGuardedCode,
  formatToolJson,
  searchDocuments,
  tokenizeQuery,
} from '../src/core.mjs';

test('tokenizeQuery handles API punctuation and camel case', () => {
  const terms = tokenizeQuery('SCH_PrimitiveComponent.createNetPort getAll');
  assert.ok(terms.includes('sch_primitive'));
  assert.ok(terms.includes('component.create'));
  assert.ok(terms.includes('net'));
  assert.ok(terms.includes('port'));
  assert.ok(terms.includes('get'));
  assert.ok(terms.includes('all'));
});

test('searchDocuments ranks partial multi-symbol coverage instead of requiring one-line AND matches', () => {
  const documents = [
    {
      file: 'references/classes/SCH_PrimitiveComponent.md',
      scope: 'api',
      lines: [
        '# SCH_PrimitiveComponent class',
        'function createNetPort(direction, net, x, y, rotation, mirror)',
        'function delete(primitiveIds): Promise<boolean>',
        'function getAll(componentType, allSchematicPages)',
      ],
    },
    {
      file: 'guide/index.md',
      scope: 'guide',
      lines: ['General extension guide'],
    },
  ];
  const result = searchDocuments(
    documents,
    'SCH_PrimitiveComponent getAll delete createNetPort',
    { maxResults: 4, contextLines: 0 },
  );
  assert.ok(result.returned >= 2);
  assert.equal(result.results[0].file, 'references/classes/SCH_PrimitiveComponent.md');
  assert.ok(result.results.some((item) => item.excerpt.includes('createNetPort')));
  assert.ok(result.results.some((item) => item.excerpt.includes('delete')));
});

test('formatToolJson bounds arrays and large strings in compact mode', () => {
  const value = {
    rows: Array.from({ length: 100 }, (_, index) => ({ index, text: 'x'.repeat(100) })),
    note: 'y'.repeat(5_000),
  };
  const formatted = formatToolJson(value, { mode: 'compact', maxChars: 4_000, maxArrayItems: 5 });
  const parsed = JSON.parse(formatted.text);
  assert.equal(parsed.rows.length, 6);
  assert.equal(parsed.rows[5].__omittedItems, 95);
  assert.match(parsed.note, /chars omitted/);
  assert.ok(formatted.text.length <= 4_000);
});

test('formatToolJson emits a valid bounded envelope when a full result is too large', () => {
  const formatted = formatToolJson({ raw: 'z'.repeat(50_000) }, { mode: 'full', maxChars: 1_500 });
  const parsed = JSON.parse(formatted.text);
  assert.equal(parsed.truncated, true);
  assert.ok(formatted.text.length <= 1_500);
});

test('buildGuardedCode injects precise context checks before user code', () => {
  const code = buildGuardedCode('return { ok: true };', {
    projectUuid: 'project-1',
    documentUuid: 'document-2',
    documentType: 3,
  });
  assert.match(code, /getCurrentProjectInfo/);
  assert.match(code, /getCurrentDocumentInfo/);
  assert.match(code, /project-1/);
  assert.match(code, /document-2/);
  assert.match(code, /documentType !== 3/);
  assert.ok(code.endsWith('return { ok: true };'));
});
